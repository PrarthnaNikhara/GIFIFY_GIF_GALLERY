import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials";
import { Signika_Negative } from "next/font/google";
export const authOptions = {
    pages: {
        signIn: '/signin'
    },
    providers: [
        CredentialsProvider({
            name: 'Credentials',
            credentials: {},
            async authorize(credentials): Promise<any> {
                return await SignIWithEmailAndPassword(auth, (credentials as any).emaail || '', (credentials as any).password || '')
                    .then(userCredential => {
                        if (userCredential.user) {
                            return userCredential.user;
                        }
                        return null;
                    })
                    .catch(error => (console.log(error)))

            }
        })
    ],

}

export default NextAuth(authOptions)